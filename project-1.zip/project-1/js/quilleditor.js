var quill = new Quill('#description-editor', {
    theme: 'snow'
  });
  
  // Get the HTML content from Quill and update the hidden input field
  var descriptionInput = document.getElementById('description');
  quill.on('text-change', function() {
    descriptionInput.value = quill.root.innerHTML;
  });

  