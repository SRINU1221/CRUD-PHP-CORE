// $(document).ready(function(){

//     $('#submit-button').click(function(event){
//         event.preventDefault();
//         var name = $('#name').val();
//         var state = $('#state').val();
//         var city = $('#city').val();
//         var address = $('#address').val();
//         var zipcode = $('#zip_code').val();
//         var phone_number = $('#phone_number').val();
//         var email = $('#email').val();
//         var data = {
//             name:name,
//             state:state,
//             city:city,
//             address:address,
//             zipcode:zipcode,
//             phone_number:phone_number,
//             email:email
//         }
//         $.ajax({
//             url: 'controllers/addcentre.php',
//             type: 'post',
//             data: data,
//             success: function(response) {
//                 alert(response);
//             },
//             error: function(xhr, status, error) {
//                 console.log('Error:', error);
//             }
//         });
//     })
// })


