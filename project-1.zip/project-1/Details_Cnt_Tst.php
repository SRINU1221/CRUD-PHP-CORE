<?php
include_once('./view/header.php')
?>

<section class="au-breadcrumb m-t-75 m-b-30">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="au-breadcrumb-content">
                        <div class="au-breadcrumb-left">
                            <h3>Welcome Admin</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <div class="table-responsive table--no-card m-b-30">
                        <table class="table table-borderless table-striped table-earning">
                            <thead>
                                <tr>
                                    <th>Serial Number</th>
                                    <th>Test Names</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="tableBody"></tbody>
                        </table>
                    </div>
                </div>
                <div class="col-sm-6">
                <div class="table-responsive table--no-card m-30">
                        <table class="table table-borderless table-striped table-earning">
                            <thead>
                                <tr>
                                    <th>Serial Number</th>
                                    <th>Centre Names</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="centreBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<script>
    $(document).ready(function() {
        $.get('./controllers/getTestDetails.php', function(data) {
            var testData = JSON.parse(data);
            var tableBody = $('#tableBody');
            var tableContent = ''; // Variable to store the HTML content
            var serialNumber = 1;
            for (var key in testData) {
                if (testData.hasOwnProperty(key)) {
                    ;
                    var testName = testData[key];

                    var row = '<tr>' +
                        '<td>' + serialNumber + '</td>' +
                        '<td>' + testName + '</td>' +
                        '<td><button class="btn btn-danger" onclick="deleteTest(' + key + ')" >Delete</button></td>' +
                        '</tr>';

                    tableContent += row; // Append each row to the table content
                }
                serialNumber = serialNumber + 1
            }

            tableBody.html(tableContent); // Set the table content as HTML of the tbody
        });
    });

    function deleteTest(key) {
        $.ajax({
            url: './controllers/testDelete.php',
            type: 'POST',
            data: {
                key: key
            },
            success: function(response) {
                alert("Successfully deleted the test");

                // Perform any additional actions after successful deletion
            },
            error: function(xhr, status, error) {
                alert("Error occurred while deleting the test");
                // Handle the error if deletion fails
            }
        });
    }
</script>


<script>
    $(document).ready(function() {
        $.get('./controllers/getCentreDetails.php', function(data) {
            var testData = JSON.parse(data);
            var tableBody = $('#centreBody');
            var tableContent = ''; // Variable to store the HTML content
            var serialNumber = 1;
            for (var key in testData) {
                if (testData.hasOwnProperty(key)) {
                    ;
                    var testName = testData[key];

                    var row = '<tr>' +
                        '<td>' + serialNumber + '</td>' +
                        '<td>' + testName + '</td>' +
                        '<td><button class="btn btn-danger" onclick="deleteTest(' + key + ')" >Delete</button></td>' +
                        '</tr>';

                    tableContent += row; // Append each row to the table content
                }
                serialNumber = serialNumber + 1
            }

            tableBody.html(tableContent); // Set the table content as HTML of the tbody
        });
    });

    function deleteTest(key) {
        $.ajax({
            url: './controllers/centreDelete.php',
            type: 'POST',
            data: {
                key: key
            },
            success: function(response) {
                alert("Successfully deleted the test");
            },
            error: function(xhr, status, error) {
                alert("Error occurred while deleting the test");
                // Handle the error if deletion fails
            }
        });
    }
</script>

<?php
include_once('./view/footer.php');
?>