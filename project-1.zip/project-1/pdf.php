<!DOCTYPE html>
<html>

<head>
    <style>
        .pdf-container {
            position: relative;
            width: 100%;
            height: 100vh;
            overflow: auto;
        }

        .pdf-page {
            display: none;
            margin-bottom: 20px;
        }
    </style>
    <script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
    <script>
        // Set the worker source explicitly
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://mozilla.github.io/pdf.js/build/pdf.worker.js';
    </script>
</head>

<body>
    <?php
    require_once('./model/conn.php');
    $sql = 'SELECT * FROM pdf;';
    $result = mysqli_query($conn, $sql);

    $pdf = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $pdf[] = $row['pdf'];
        }
    }
    mysqli_close($conn);
    ?>

    <?php
    foreach ($pdf as $pdfURL) {
        echo '<div class="pdf-container"></div>';
    }
    ?>

    <script>
var pdfLinks = ['RESUME-9.pdf','RESUME-9.pdf','RESUME-9.pdf','RESUME-9.pdf'];
        console.log(pdfLinks);

        document.addEventListener('DOMContentLoaded', function() {
            var containers = document.getElementsByClassName('pdf-container');

            for (var i = 0; i < containers.length; i++) {
                var container = containers[i];
                container.addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                });
                container.addEventListener('selectstart', function(e) {
                    e.preventDefault();
                });

                displayPDF(container, pdfLinks[i]);
            }
        });

        function displayPDF(container, pdfURL) {
            pdfjsLib.getDocument(pdfURL).promise.then(function(pdf) {
                var pageCount = pdf.numPages;
                var pagePromises = [];

                for (var i = 1; i <= pageCount; i++) {
                    var pageContainer = document.createElement('div');
                    pageContainer.className = 'pdf-page';
                    container.appendChild(pageContainer);

                    var pagePromise = pdf.getPage(i).then(function(page) {
                        var canvas = document.createElement('canvas');
                        pageContainer.appendChild(canvas);

                        var viewport = page.getViewport({
                            scale: 1
                        });
                        canvas.width = viewport.width;
                        canvas.height = viewport.height;

                        var renderContext = {
                            canvasContext: canvas.getContext('2d'),
                            viewport: viewport
                        };

                        return page.render(renderContext).promise;
                    });

                    pagePromises.push(pagePromise);
                }

                function displayPages(index) {
                    if (index >= pageCount) {
                        return;
                    }

                    pagePromises[index].then(function() {
                        var pages = container.getElementsByClassName('pdf-page');
                        pages[index].style.display = 'block';

                        pages[index].scrollIntoView({
                            behavior: 'smooth'
                        });

                        displayPages(index + 1);
                    });
                }

                displayPages(0);
            });
        }
    </script>
</body>

</html>
