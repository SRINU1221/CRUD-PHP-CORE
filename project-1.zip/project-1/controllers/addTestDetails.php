<?php
require_once("../model/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $centername= $_POST['centername'];
    $testName = $_POST['testname'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $sql = "INSERT INTO prices (CenterID,TestID,TestPrice,description) VALUES ('$centername','$testName','$price','$description')";
    mysqli_query($conn, $sql);
    mysqli_close($conn);
    echo "Data Added Successfully";    
}

