<?php
require_once("../model/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Test = $_POST['Test'];
    $countTest = count($Test);
    $successcount = 0;

    for ($i = 0; $i < $countTest; $i++) {
        $TestName = $Test[$i];
            $sql = "INSERT INTO tests (TestName) VALUES ('$TestName')";
        if (mysqli_query($conn, $sql)) {
            $successcount++;

        
        } else {
            echo "Error: " . mysqli_error($conn);
        }
        
    }
    echo $successcount ." Centres are  saved successfully!";
    mysqli_close($conn);
}

