<?php
require_once('../model/conn.php');

$sql1 = 'SELECT count(*) FROM centers;';
$sql2 = 'SELECT count(*) FROM tests;';

$result1 = mysqli_query($conn, $sql1);
$count1 = mysqli_fetch_row($result1)[0];

$result2 = mysqli_query($conn, $sql2);
$count2 = mysqli_fetch_row($result2)[0];
mysqli_close($conn);

$response = array('count1' => $count1, 'count2' => $count2);
echo json_encode($response);
?>
