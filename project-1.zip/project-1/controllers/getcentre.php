<!-- 
require_once('../model/conn.php');

$sql = 'SELECT name FROM diagnostic_centers';
$result = mysqli_query($conn, $sql);

$centerNames = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $centerNames[] = $row['name'];
    }
}

mysqli_close($conn);

echo json_encode($centerNames); -->
