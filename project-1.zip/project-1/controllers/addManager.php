<?php

require_once("../model/conn.php");

echo json_encode($_POST);
?>

