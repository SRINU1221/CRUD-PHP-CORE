<?php
require_once("../model/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $centres = $_POST['centres'];
    $countCentres = count($centres);
    $successcount = 0;

    for ($i = 0; $i < $countCentres; $i++) {
        $centerName = $centres[$i];
            $sql = "INSERT INTO centers (CenterName) VALUES ('$centerName')";
        if (mysqli_query($conn, $sql)) {
            $successcount++;

        
        } else {
            echo "Error: " . mysqli_error($conn);
        }
        
    }
    echo $successcount ." Centres are  saved successfully!";
    mysqli_close($conn);
}

