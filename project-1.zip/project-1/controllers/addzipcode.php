<?php
require_once("../model/conn.php");
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Test = $_POST['zipcode'];
    $countTest = count($Test);
    $successcount = 0;
    for ($i = 0; $i < $countTest; $i++) {
        $TestName = $Test[$i];
            $sql = "INSERT INTO zipcode (zipcode) VALUES ('$TestName')";
        if (mysqli_query($conn, $sql)) {
            $successcount++;
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }

    echo $successcount ." Zipcodes are  added successfully!";
    mysqli_close($conn);
}


