<?php
require_once('../model/conn.php');

$sql = "SELECT CenterID, CenterName FROM centers";

$result = mysqli_query($conn, $sql);

$centerNames = array(); // Array to store the test names

if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    $centerID = $row['CenterID'];
    $centerName = $row['CenterName'];
    $centerNames[$centerID] = $centerName;
  }
}
mysqli_close($conn);

echo json_encode($centerNames);
?>
