<?php
require_once('../model/conn.php');

if(isset($_POST['key'])) {
  $key = $_POST['key'];

  // Perform the deletion query
  $sql = "DELETE FROM centers WHERE centerID = '$key'";
  $result = mysqli_query($conn, $sql);

  if($result) {
    echo "Test deleted successfully";
  } else {
    echo "Failed to delete the test";
  }
} else {
  echo "Invalid request";
}

mysqli_close($conn);
?>
