<?php
require_once('../model/conn.php');

$sql = "SELECT TestID, TestName FROM tests";

$result = mysqli_query($conn, $sql);

$testNames = array(); // Array to store the test names

if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    $testID = $row['TestID'];
    $testName = $row['TestName'];
    $testNames[$testID] = $testName;
  }
}
mysqli_close($conn);

echo json_encode($testNames);
?>
