<?php
include_once('./view/header.php');
?>
<section class="au-breadcrumb m-t-75">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="au-breadcrumb-content">
                        <div class="au-breadcrumb-left">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="section__content justify-content-center section__content--p30 ">
    <div class="container-fluid">
        <div class="col-xl-6  mx-auto">
            <div class="card">
                <div class="card-header">Add Tests</div>
                <div class="card-body">
                    <div class="card-title">
                        <h3 class="text-center title-2">Test</h3>
                    </div>
                    <hr>
                    <form method="post">
                        <div class="form-group">
                            <label for="center-name" class="control-label mb-1">Name of the Test</label>
                            <select id="center-name" name="center-name" class="form-control" aria-required="true" aria-invalid="false"></select>
                        </div>

                        <div class="form-group">
                            <label for="test-name" class="control-label mb-1">Name of the Test</label>
                            <select id="test-name" name="test-name" class="form-control" aria-required="true" aria-invalid="false"></select>
                        </div>



                        <div class="form-group has-success">
                            <label for="description" class="control-label mb-1">Description</label>
                            <div id="description-editor"></div>
                            <input id="description" name="description" type="hidden" data-val="true" data-val-required="Please enter the name on card" autocomplete="description" aria-required="true" aria-invalid="false" aria-describedby="description-error">
                            <span class="help-block field-validation-valid" data-valmsg-for="description" data-valmsg-replace="true"></span>
                        </div>

                        <div class="form-group">
                            <label for="price" class="control-label mb-1">Price</label>
                            <input id="price" name="price" type="tel" class="form-control identified visa" value="" data-val="true" data-val-required="Please enter the card number" data-val-cc-number="Please enter a valid card number" autocomplete="price">
                            <span class="help-block" data-valmsg-for="price" data-valmsg-replace="true"></span>
                        </div>
                        <div>
                            <button id="submit-test-button" type="submit" class="btn btn-lg btn-info btn-block">
                                <i class="fa fa-paper-plane"></i>&nbsp;
                                <span id="submit-test-button-text">Submit Test</span>
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/quilleditor.js"></script>
<script>
    $(document).ready(function() {
        $('#submit-test-button').click(function(event) {
            event.preventDefault()
            centername = $('#center-name').val()
            testname = $('#test-name').val();
            description = $('#description').val()
            price = $('#price').val()
            var data = {
                centername: centername,
                testname: testname,
                description: description,
                price: price
            }
            $.ajax({
                url: './controllers/addTestDetails.php',
                type: 'post',
                data: data,
                success:function(response){
                    alert(response)
                }
            })
        })
    })
</script>
<script>
    $(document).ready(function() {
        // AJAX request to fetch test names
        $.post("./controllers/getTestDetails.php", function(response) {
                var dropdown = $("#test-name");
                $.each(Object.entries(response), function(index, [testID, testName]) {
                    dropdown.append($('<option></option>').val(testID).text(testName));
                });
            }, "json")
            .fail(function() {
                console.log("Failed to fetch test names.");
            });
    });
</script>
<script>
    $(document).ready(function() {
        // AJAX request to fetch test names
        $.post("./controllers/getCentreDetails.php", function(response) {
                var dropdown = $("#center-name");
                $.each(Object.entries(response), function(index, [centerID, centerName]) {
                    dropdown.append($('<option></option>').val(centerID).text(centerName));
                });
            }, "json")
            .fail(function() {
                console.log("Failed to fetch center names.");
            });
    });
</script>
<?php
include_once('./view/footer.php');

?>