<?php
include_once('view/header.php');
?>
<section class="au-breadcrumb m-t-75">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="au-breadcrumb-content">
                        <div class="au-breadcrumb-left">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 mx-auto">
                    <div class="card">
                        <div class="card-header">Diagnostics Centres</div>
                        <div class="card-body">
                            <div class="card-title">
                                <h3 class="text-center title-2">Add zipcode</h3>
                            </div>
                            <form method="post" id="addcentre">
                                <style>
                                    .float-right {
                                        float: right;
                                    }
                                </style>

                                <hr>
                                <div id="test-fields">
                                    <div class="form-group">
                                        <label for="name" class="control-label mb-1">Enter Zipcode</label>
                                        <input id="name" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                    </div>
                                </div>
                                <div>
                                    <button id="add-button" type="button" class="btn btn-primary float-right" onclick="addzipcode()">
                                        Add zipcode
                                    </button>
                                    <button id="submit-button" type="button" class="btn btn-lg btn-info btn-block" onclick="submitForm()">
                                        <i class="fa fa-paper-plane"></i>&nbsp;
                                        <span id="centre-button-Submit">Submit zipcode</span>
                                    </button>
                                </div>

                            </form>
                            <script>
                                var centreFields = document.getElementById("test-fields");
                                var centres = [];
                                function addzipcode() {
                                    var newField = document.createElement("div");
                                    newField.classList.add("form-group");
                                    newField.innerHTML = `
                                        <label for="name" class="control-label mb-1">Enter Zipcode</label>
                                        <input name="name" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                    `;
                                    centreFields.appendChild(newField);
                                }
                                function submitForm() {
                                    zipcode = [];

                                    var nameFields = document.getElementsByName("name");
                                    for (var i = 0; i < nameFields.length; i++) {
                                        zipcode.push(nameFields[i].value);
                                    }
                                    $.ajax({
                                        url: 'controllers/addzipcode.php',
                                        type: 'post',
                                        data: {
                                            zipcode: zipcode
                                        }, 
                                        success: function(response) {
                                            alert(response)
                                        }
                                    });

                                    centreFields.innerHTML = `
                                        <div class="form-group">
                                            <label for="name" class="control-label mb-1">Enter Zipcode</label>
                                            <input id="name" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false">
                                        </div>`;
                                }

                            </script>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php include_once('./view/footer.php'); ?>