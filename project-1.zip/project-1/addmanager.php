<?php
include_once('view/header.php');
?>
<section class="au-breadcrumb m-t-75">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="au-breadcrumb-content">
                        <div class="au-breadcrumb-left">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 mx-auto">
                    <div class="card">
                        <div class="card-header">Diagnostics Centres</div>
                        <div class="card-body">
                            <div class="card-title">
                                <h3 class="text-center title-2">Add Managers</h3>
                            </div>
                            <form method="post" id="addcentre">
    <style>
        .float-right {
            float: right;
        }
    </style>

    <hr>
    <div id="manager-fields">
        <div class="row">
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="name" class="control-label mb-1">Name of the Manager</label>
                    <input name="name" type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="email" class="control-label mb-1">Email</label>
                    <input name="email" type="email" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="contact" class="control-label mb-1">Contact Number</label>
                    <input name="contact" type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="address" class="control-label mb-1">Address</label>
                    <input name="address" type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
        </div>
    </div>
    <div>
        <button id="add-button" type="button" class="btn btn-primary float-right" onclick="addManager()">Add Manager</button>
        <button id="submit-button" type="button" class="btn btn-lg btn-info btn-block" onclick="submitForm()">Submit Test</button>
    </div>
</form>

<script>
    var centreFields = document.getElementById("manager-fields");
    var managers = [];

    function addManager() {
        var newFieldHTML = `
        <div class="row">
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="name" class="control-label mb-1">Name of the Manager</label>
                    <input name="name" type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="email" class="control-label mb-1">Email</label>
                    <input name="email" type="email" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="contact" class="control-label mb-1">Contact Number</label>
                    <input name="contact" type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
            <div class="col-xl-6">
                <div class="form-group">
                    <label for="address" class="control-label mb-1">Address</label>
                    <input name="address" type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
            </div>
        </div>`;

        $(centreFields).append(newFieldHTML);
    }

    function submitForm() {
        $("form#addcentre").find("div[id='manager-fields']").each(function() {
            var manager = {};
            manager.name = $(this).find("input[name='name']").val();
            manager.email = $(this).find("input[name='email']").val();
            manager.contact = $(this).find("input[name='contact']").val();
            manager.address = $(this).find("input[name='address']").val();
            managers.push(manager);
        });

        console.log();

        // Reset form fields
        $("form#addcentre").find("input[type='text'], input[type='email']").val("");
        // Clear added manager fields
        $(centreFields).html("");
    }
</script>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php include_once('./view/footer.php'); ?>